package com.appian;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.concurrent.Callable;

public class QueryTimer {

  public static void main(String[] args) throws Exception {
    if (args.length < 3) {
      System.out.println("Usage:");
      System.out.println("   QueryTimer <driverClass> <connectionUrl> <user>");
      System.out.println("Examples");
      System.out.println("   QueryTimer com.mysql.jdbc.Driver jdbc:mysql://localhost:3306/AppianDB appian");
      System.out.println("   QueryTimer oracle.jdbc.OracleDriver jdbc:oracle:thin:@172.17.0.1:1521:citest appian");
      System.exit(1);
    }
    final String driverName = args[0];
    final String url = args[1];
    final String user = args[2];

    Class cls = Class.forName(driverName);
    Driver driver = (Driver)cls.newInstance();
    DriverManager.registerDriver(driver);

    String password = args.length == 4 ? args[3] : ask("Password: ");
    final Connection connection = timing("creating connection", () -> DriverManager.getConnection(url, user, password));

    StringBuffer query = new StringBuffer();
    while(true) {
      String line = ask(query.length() > 0 ? "" : "Query> ");
      if (line.equalsIgnoreCase("quit")) {
        break;
      }
      query.append(line).append(' ');
      if (!line.trim().endsWith(";")) {
        continue;
      }
      long start = System.currentTimeMillis();
      String stmt = query.toString();
      query = new StringBuffer();
      try (PreparedStatement pstmt = timing("prepare statement", () -> connection.prepareStatement(stmt));
           ResultSet rs = timing("execute query", () -> pstmt.executeQuery())) {
        timing("fetch resultset metadata", () -> displayResultSetMetadata(rs.getMetaData()));
        while (rs.next()) {
          timing("fetch resultset row", () -> displayResultSetRow(rs));
        }
      }
      System.out.println("Total Query Execution time: " + (System.currentTimeMillis() - start) + " msecs");
    }

    connection.close();
  }

  private static String ask(String prompt) throws IOException {
    System.out.print(prompt);
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    return br.readLine();
  }

  private static <T> T timing(String label, Callable<T> callable) throws Exception {
    long start = System.currentTimeMillis();
    try {
      return callable.call();
    } finally {
      System.out.println(label + " took " + (System.currentTimeMillis() - start) + " msecs");
    }
  }

  private static boolean displayResultSetMetadata(ResultSetMetaData rsMd) throws SQLException {
    int nCols = rsMd.getColumnCount();
    for (int i = 1; i <= nCols; i++) {
      System.out.print(rsMd.getColumnName(i));
      System.out.print(",");
    }
    System.out.println();
    return true;
  }

  private static boolean displayResultSetRow(ResultSet rs) throws SQLException {
    int nCols = rs.getMetaData().getColumnCount();
    for (int i = 1; i <= nCols; i++) {
      System.out.print(rs.getString(i));
      System.out.print(",");
    }
    System.out.println();
    return true;
  }
}
