#!/usr/bin/env bash

mkdir -p classes
javac -d classes QueryTimer.java

DRIVERS=/usr/local/appian/ae/tomcat/apache-tomcat/lib/ojdbc8-19.7.jar
DRIVERS=$DRIVERS:/usr/local/appian/ae/tomcat/apache-tomcat/lib/mariadb-java-client-2.7.2.jar

java -cp classes:$DRIVERS com.appian.QueryTimer $*

